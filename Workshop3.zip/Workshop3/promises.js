const promiseOne = new Promise(function(resolve , reject) {
    setTimeout(() => {
        console.log('Async task is complete');
        resolve()
    }, 1000);
})

promiseOne.then(function () {
    console.log("promise consumed")
})


new Promise( function (resolve,reject) {
    setTimeout(function () {
        console.log("Async 2");
        resolve()
    }, 1000)
}).then(()=>{
        console.log("async 2 resolved ");
        
    })


    const promiseThree = new  Promise(function(resolve,reject){
        setTimeout(function () {
            resolve({username: "jay" , email: "jay@prem.com" })
        }, 1000)
    })

    promiseThree.then(function(user){
        console.log(user);
        
    })

     const promiseFour = new  Promise(function(resolve,reject){
        setTimeout(function () {
          let error = true;
          if (!error) {
            resolve({username: "jay" , password: "1234" })
          }else{
            reject("error: something went wrong")
          }
        }, 1000)
    })
    
    promiseFour
    .then((user)=>{
        console.log(user);
        return user.username;
    }).then((username)=>{
        console.log(username);
        
    }).catch((error)=>{
        console.log(error)
    }).finally(()=> 
        console.log("The promise is either resolve or rejected")
)

promiseFive = new Promise((resolve,reject)=>{
setTimeout(() => {
    let error = true;
    if(!error){
     resolve({username: "jay" , password: "1234" })
    }else{
        reject("something : Went Wrong")
    }
}, 1000);
})

async function consumedFive() {
   try{
    const responce = await promiseFive
   console.log(responce);
}catch(error){
console.log(error);
}
}
consumedFive()  

//using Fetch find data from api

// fetch("url").
// then((responce)=>{
//     return responce.json;
// }).then((data)=>{
//     console.log(data);
// }).catch((error) => console.log("e:",error)
// )